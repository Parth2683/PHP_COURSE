<?php
ini_set('error_reporting', E_ALL);
ini_set('display_errors', '1');

// Time zone needs to be set only when using date-related functions
date_default_timezone_set('America/Los_Angeles');
