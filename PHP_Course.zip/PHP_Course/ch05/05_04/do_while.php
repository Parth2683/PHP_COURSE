<?php
// initialize counter
$i = 100;

// No alternative syntax
do {
    // increment counter
    $i++;
    echo $i . '<br>';
} while ($i < 10);
