<?php
// initialize counter
$i = 0;

while ($i < 10) :
    // increment counter
    $i++;
    echo $i . '<br>';
endwhile;
