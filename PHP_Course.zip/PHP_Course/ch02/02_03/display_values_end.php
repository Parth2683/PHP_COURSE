<?php
$firstName = 'David';
$prénom = 'David';
//$first-Name = 'David';
//$1stName = 'David';
$number = 4200.99;

//echo $number, ' ', $firstName;
//print $number;
echo $prénom;