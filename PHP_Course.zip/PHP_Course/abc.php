<!-- Chapter 1 -->
	<h1 align="center">Introduction Of PHP Language</h1>
<!-- Chapter 1-->

<?/*
<!-- Chapter 2 -->

	<?php
		$x = ['first','second','third'];
		$x['first'] = ['first_first','first_second','first_third'];
		$x['second'] = ['second_first','second_second','second_third'];
		$x['third'] = ['third_first','third_second','third_third'];
		$x['four']['four_one'] = ['first','second'];
		$x['four']['four_two'] = ['first','second'];

		echo '<pre>';
			print_r($x);
			// var_dump($x);
		echo '</pre>';

		$book = [
			'title' => 'three mistake of my life',
			'author' => 'chetan bhagat',
			'description' => 'this is story about living life'
		];

		$charchter = ['live happy','be yourself','never lose hope'];
	?>

	<h1><?= "{$book['title']} by {$book['author']}";   ?> </h1>
	<h4><?= "Title of book is '{$book["title"]}' and Description is: '{$book["description"]}'." ?></h4>
	<ul>
		<li><?= $charchter[0]; ?></li>
		<li><?= $charchter[1]; ?></li>
		<li><?= $charchter[2]; ?></li>
	</ul>

<!-- Chapter 2 -->
*/?>

<!-- Chapter 3 -->
	<?php 
		$name = 'urvish';
		$surname = 'patel';

		if ($name=='urvish' || $surname == 'kapatel')
		// if ($name=='urvish' || $surname == 0)
		{
			echo "this is first";
		}
		elseif ($name=='vishal' && $surname == 'shah')
		{
			echo "this is second";
		}else{
			echo "this is last";
		}
		// echo $name;
		// var_dump($name);

		
	?>
<!-- Chapter 3