<?php

$version = phpversion();

$name = 'DAVID';
//echo strtolower($name);
//echo '<br>';

$name = ucfirst(strtolower($name));

echo $name;