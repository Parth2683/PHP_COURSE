<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Setup Test</title>
    <style>
        body {
            background-color: #fff;
            color: #111;
            font-family: "Lucida Sans Unicode", "Lucida Sans", sans-serif;
            font-size: 85%;
            margin-left: 15px;
        }
        h1 {
            color: #0E618C;
        }
    </style>
</head>
<body>
<h1>Congratulations!</h1>
<p>Today is <?= date('l'); ?>.</p>
<p>If the current day of the week is displayed, you look good to go.</p>
</body>
</html>