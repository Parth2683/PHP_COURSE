<?php
$a = 5.8;
$b = 2.9;

echo $a % $b;