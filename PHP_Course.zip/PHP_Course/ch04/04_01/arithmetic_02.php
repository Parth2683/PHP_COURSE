<?php
$a = 5;
$b = 2;

echo $a / $b;